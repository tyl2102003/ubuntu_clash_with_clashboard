Welcome to join us. Please read the following instructions to setup your local development environment.

First, install `pnpm` according to [the official document](https://pnpm.io/installation).

then, install some necessary depdencies:

```shell
pnpm install
```

you can run it once you have finished it.

```shell
pnpm start
```
